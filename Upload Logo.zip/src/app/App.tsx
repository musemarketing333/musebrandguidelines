import { useState, useEffect, useRef } from "react";
import { Copy, Check, ChevronDown } from "lucide-react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import logoImg from "@/imports/542290000_17882308809373350_6037036500574163784_n.jpg";

// ─── Color data ───────────────────────────────────────────────────────────────

const primaryColors = [
  {
    name: "Crimson Rose",
    hex: "#810B38",
    cmyk: "C0 M91 Y56 K49",
    pantone: "PMS 202 C",
    role: "Brand signature. Primary CTAs, hero headlines, logo mark on light.",
  },
  {
    name: "Deep Burgundy",
    hex: "#541A1A",
    cmyk: "C0 M69 Y69 K67",
    pantone: "PMS 7421 C",
    role: "Dark surfaces, footer grounds, text on parchment.",
  },
  {
    name: "Sage",
    hex: "#869B7E",
    cmyk: "C13 M0 Y19 K39",
    pantone: "PMS 5575 C",
    role: "Editorial contrast. Secondary accents, botanical supporting element.",
  },
];

const neutralColors = [
  {
    name: "Sand",
    hex: "#DCC3AA",
    cmyk: "C0 M12 Y23 K14",
    pantone: "PMS 9141 C",
    role: "Warm dividers, muted fills, tertiary backgrounds.",
  },
  {
    name: "Parchment",
    hex: "#F1E2D1",
    cmyk: "C0 M7 Y14 K6",
    pantone: "PMS 9122 C",
    role: "Primary canvas. Page backgrounds, warm surface areas.",
  },
  {
    name: "Ivory",
    hex: "#F6F3EB",
    cmyk: "C0 M2 Y5 K4",
    pantone: "PMS 9101 C",
    role: "Brightest surface. Cards, panels, reversed text backdrops.",
  },
  {
    name: "Espresso",
    hex: "#2A1010",
    cmyk: "C0 M62 Y62 K84",
    pantone: "PMS 4975 C",
    role: "Body text on light grounds. Near-black with warmth.",
  },
];

// ─── Typography specimens ──────────────────────────────────────────────────────

const typeScale = [
  { label: "Display", size: "clamp(3rem, 8vw, 7rem)", weight: 500, font: "display", sample: "Artistry in every strand." },
  { label: "H1", size: "clamp(2rem, 4vw, 3.5rem)", weight: 500, font: "display", sample: "Hair & Makeup Studio" },
  { label: "H2", size: "clamp(1.5rem, 2.5vw, 2.25rem)", weight: 500, font: "display", sample: "Our Services" },
  { label: "H3", size: "1.25rem", weight: 500, font: "sans", sample: "Bridal Collection" },
  { label: "Body", size: "1rem", weight: 400, font: "sans", sample: "We believe beauty is a state of being — not something applied, but something revealed. Each appointment is a collaboration between artist and muse." },
  { label: "Caption", size: "0.8125rem", weight: 300, font: "sans", sample: "Appointments available Wednesday – Sunday" },
  { label: "Label", size: "0.6875rem", weight: 500, font: "sans", sample: "BOOK CONSULTATION", letterSpacing: "0.18em", uppercase: true },
];

// ─── Brand voice ──────────────────────────────────────────────────────────────

const voiceWords = [
  {
    word: "Elevated",
    description: "We speak with intention and care. Language is unhurried, precise, and never overwrought.",
    do: "\"Your appointment has been confirmed for Saturday at 2 pm.\"",
    dont: "\"Can't wait to see ya!! 🎉 Your booking is ALL SET!!!\"",
  },
  {
    word: "Intimate",
    description: "We treat every client as an individual with a distinct story, never as a transaction.",
    do: "\"Tell us how you'd like to feel when you walk out the door.\"",
    dont: "\"Select your service from the menu below.\"",
  },
  {
    word: "Artful",
    description: "We refer to our work as craft. Hair and makeup are living art forms worthy of serious respect.",
    do: "\"Anahita approaches each look as a painter approaches a canvas — with full presence.\"",
    dont: "\"We do great hair and makeup at affordable prices!\"",
  },
  {
    word: "Confident",
    description: "Quiet authority. We don't need to shout because our work speaks. No superlatives, no hard sells.",
    do: "\"Reserve your date.\"",
    dont: "\"Book now before spots fill up!! Limited availability!!\"",
  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function useIntersect(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

function CopyHex({ hex }: { hex: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(hex);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button
      onClick={copy}
      className="flex items-center gap-1.5 text-xs font-mono opacity-50 hover:opacity-100 transition-opacity"
    >
      {copied ? <Check size={11} /> : <Copy size={11} />}
      {hex}
    </button>
  );
}

function ColorCard({ color, index }: { color: typeof primaryColors[0]; index: number }) {
  const { ref, visible } = useIntersect();
  const isLight = ["#F6F3EB", "#F1E2D1", "#DCC3AA"].includes(color.hex);
  return (
    <div
      ref={ref}
      className="flex flex-col transition-all duration-700"
      style={{ opacity: visible ? 1 : 0, transform: visible ? "none" : "translateY(20px)", transitionDelay: `${index * 80}ms` }}
    >
      <div
        className="w-full h-48 transition-transform duration-500 hover:scale-[1.02]"
        style={{ backgroundColor: color.hex, border: isLight ? "1px solid rgba(42,16,16,0.1)" : "none" }}
      />
      <div className="pt-4 pb-2">
        <div className="flex items-start justify-between mb-2">
          <p style={{ fontFamily: "var(--font-display)", fontSize: "1.1rem" }} className="text-foreground">
            {color.name}
          </p>
          <CopyHex hex={color.hex} />
        </div>
        <p className="text-xs text-foreground/40 font-mono mb-1">{color.cmyk}</p>
        <p className="text-xs text-foreground/40 mb-3">{color.pantone}</p>
        <div className="w-8 h-px bg-foreground/20 mb-3" />
        <p className="text-xs text-foreground/50 leading-relaxed">{color.role}</p>
      </div>
    </div>
  );
}

function Section({ id, children }: { id: string; children: React.ReactNode }) {
  return (
    <section id={id} className="px-6 md:px-16 lg:px-24 py-24">
      {children}
    </section>
  );
}

function SectionLabel({ num, label }: { num: string; label: string }) {
  return (
    <div className="flex items-center gap-4 mb-16">
      <span className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30">{num}</span>
      <div className="flex-1 h-px bg-foreground/10" />
      <span className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30">{label}</span>
    </div>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [navOpen, setNavOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const navLinks = [
    { href: "#brand-story", label: "Brand Story" },
    { href: "#logo", label: "Logo" },
    { href: "#colors", label: "Colors" },
    { href: "#typography", label: "Typography" },
    { href: "#voice", label: "Voice" },
    { href: "#photography", label: "Photography" },
  ];

  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
    setNavOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">

      {/* ── Navigation ─────────────────────────────────────────────────── */}
      <nav
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
        style={{ backgroundColor: scrolled ? "rgba(246,243,235,0.95)" : "transparent", backdropFilter: scrolled ? "blur(12px)" : "none", borderBottom: scrolled ? "1px solid rgba(42,16,16,0.08)" : "none" }}
      >
        <div className="flex items-center justify-between px-6 md:px-16 lg:px-24 h-16">
          <p className="text-xs tracking-[0.22em] uppercase font-medium text-foreground/60">
            Muse by Anahita
          </p>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((l) => (
              <button
                key={l.href}
                onClick={() => scrollTo(l.href)}
                className="text-[11px] tracking-[0.14em] uppercase text-foreground/50 hover:text-foreground transition-colors"
              >
                {l.label}
              </button>
            ))}
          </div>

          {/* Mobile hamburger */}
          <button onClick={() => setNavOpen(!navOpen)} className="md:hidden text-foreground/60">
            <ChevronDown size={18} className={`transition-transform ${navOpen ? "rotate-180" : ""}`} />
          </button>
        </div>

        {navOpen && (
          <div className="md:hidden border-t border-border bg-background px-6 py-4 flex flex-col gap-3">
            {navLinks.map((l) => (
              <button key={l.href} onClick={() => scrollTo(l.href)} className="text-left text-sm tracking-wide text-foreground/60 hover:text-foreground py-1">
                {l.label}
              </button>
            ))}
          </div>
        )}
      </nav>

      {/* ── Hero ───────────────────────────────────────────────────────── */}
      <div
        className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden"
        style={{ backgroundColor: "#541A1A" }}
      >
        {/* Subtle texture overlay */}
        <div className="absolute inset-0 opacity-5" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23F6F3EB' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" }} />

        <div className="relative z-10 flex flex-col items-center text-center px-8">
          {/* Logo — inverted for dark bg via CSS filter */}
          <div className="mb-12 w-52 md:w-72">
            <ImageWithFallback
              src={logoImg}
              alt="Muse by Anahita logo"
              className="w-full object-contain"
              style={{ filter: "invert(1) brightness(1.05)", mixBlendMode: "screen" }}
            />
          </div>

          <div className="w-12 h-px mb-10" style={{ backgroundColor: "rgba(246,243,235,0.25)" }} />

          <p className="text-[10px] tracking-[0.3em] uppercase mb-6" style={{ color: "rgba(246,243,235,0.45)" }}>
            Brand Guidelines
          </p>

          <h1
            className="text-white mb-6"
            style={{ fontFamily: "var(--font-display)", fontSize: "clamp(2.5rem, 7vw, 6rem)", fontWeight: 400, lineHeight: 1.05, letterSpacing: "-0.01em" }}
          >
            The Muse<br />
            <em>Identity System</em>
          </h1>

          <p className="max-w-md text-sm leading-relaxed" style={{ color: "rgba(246,243,235,0.45)", fontWeight: 300 }}>
            Visual language, color system, and brand voice for<br className="hidden md:block" />
            Muse by Anahita — a luxury hair & makeup studio.
          </p>
        </div>

        {/* Scroll cue */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-30">
          <div className="w-px h-12 bg-white/40 animate-pulse" />
        </div>
      </div>

      {/* ── Brand Story ────────────────────────────────────────────────── */}
      <Section id="brand-story">
        <SectionLabel num="01" label="Brand Story" />

        <div className="grid md:grid-cols-2 gap-16 lg:gap-32 items-start">
          <div>
            <h2
              className="mb-8 text-foreground"
              style={{ fontFamily: "var(--font-display)", fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 400, lineHeight: 1.1 }}
            >
              The word <em>muse</em> does not belong to the artist alone.
            </h2>
            <div className="w-12 h-px bg-primary mb-8" />
            <p className="text-foreground/60 leading-[1.85] text-sm md:text-base">
              Muse by Anahita was founded on a simple conviction: that the act of being seen — truly seen — is transformative. Each client who sits in the chair is not a canvas to be worked on, but a collaborator, a muse in the truest sense. Anahita's craft is the art of revelation: drawing out what is already there.
            </p>
            <p className="text-foreground/60 leading-[1.85] text-sm md:text-base mt-5">
              The studio serves brides, editorial clients, and everyday visitors seeking moments of extraordinary care. The approach is the same in all cases — unhurried, attentive, and deeply personal.
            </p>
          </div>

          <div className="flex flex-col gap-6">
            {[
              { label: "Mission", text: "To make every person feel like the most luminous version of themselves — through technique, intention, and genuine presence." },
              { label: "Vision", text: "A world where beauty appointments feel less like services and more like rituals — small acts of self-restoration." },
              { label: "Values", text: "Artistry · Intimacy · Precision · Warmth · Confidence" },
            ].map((item) => (
              <div key={item.label} className="border-l-2 pl-6" style={{ borderColor: "#810B38" }}>
                <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-primary mb-2">{item.label}</p>
                <p className="text-sm text-foreground/60 leading-relaxed">{item.text}</p>
              </div>
            ))}

            {/* Brand personality tags */}
            <div className="mt-4 pt-8 border-t border-border">
              <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30 mb-4">Personality</p>
              <div className="flex flex-wrap gap-2">
                {["Editorial", "Elevated", "Feminine", "Intimate", "Artful", "Modern", "Warm"].map((tag) => (
                  <span key={tag} className="px-3 py-1 text-xs tracking-widest uppercase border border-foreground/15 text-foreground/50">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Section>

      <div className="mx-6 md:mx-16 lg:mx-24 h-px bg-border" />

      {/* ── Logo System ────────────────────────────────────────────────── */}
      <Section id="logo">
        <SectionLabel num="02" label="Logo System" />

        <div className="mb-16">
          <h2 className="text-foreground mb-4" style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 400 }}>
            The Mark
          </h2>
          <p className="text-sm text-foreground/50 leading-relaxed max-w-lg">
            The Muse logo is a geometric open-circle mark paired with a bold geometric wordmark. The open arc suggests possibility — beauty unrestricted, artistry unfinished and ever-becoming. "By Anahita" is set in tracked small capitals, subordinate but present.
          </p>
        </div>

        {/* Logo on backgrounds */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-16">
          {[
            { bg: "#F6F3EB", label: "On Ivory", note: "Primary use", blend: "multiply" as const },
            { bg: "#F1E2D1", label: "On Parchment", note: "Secondary use", blend: "multiply" as const },
            { bg: "#541A1A", label: "On Deep Burgundy", note: "Reversed (white logo)", invert: true },
          ].map((variant) => (
            <div key={variant.label}>
              <div
                className="flex items-center justify-center p-10 aspect-square"
                style={{ backgroundColor: variant.bg, border: variant.bg === "#F6F3EB" || variant.bg === "#F1E2D1" ? "1px solid rgba(42,16,16,0.08)" : "none" }}
              >
                <ImageWithFallback
                  src={logoImg}
                  alt="Muse by Anahita logo"
                  className="w-full max-w-[180px] object-contain"
                  style={variant.invert
                    ? { filter: "invert(1) brightness(1.05)", mixBlendMode: "screen" }
                    : { mixBlendMode: variant.blend }}
                />
              </div>
              <div className="mt-4">
                <p className="text-sm font-medium text-foreground">{variant.label}</p>
                <p className="text-xs text-foreground/40 mt-0.5">{variant.note}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Logo rules */}
        <div className="grid md:grid-cols-2 gap-8">
          <div className="p-8 bg-card border border-border">
            <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-secondary mb-6">Clear Space</p>
            <p className="text-sm text-foreground/55 leading-relaxed">
              Maintain a minimum clear space equal to the cap height of the "M" in MUSE on all four sides of the mark. Never crowd the logo with text, imagery, or competing graphic elements.
            </p>
          </div>
          <div className="p-8 bg-card border border-border">
            <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-primary mb-6">Minimum Size</p>
            <p className="text-sm text-foreground/55 leading-relaxed">
              Digital minimum: 120px wide. Print minimum: 30mm wide. Below these thresholds, use the wordmark alone (MUSE) without the circle mark to ensure legibility.
            </p>
          </div>
        </div>

        {/* Don'ts */}
        <div className="mt-10">
          <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30 mb-6">Never Do This</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              "Stretch or distort the mark",
              "Apply drop shadows or effects",
              "Place on busy photographic backgrounds",
              "Recolor the mark outside the brand palette",
            ].map((rule) => (
              <div key={rule} className="p-5 border border-red-200/60 bg-red-50/40">
                <div className="w-6 h-6 rounded-full border-2 border-red-300 flex items-center justify-center mb-3">
                  <span className="text-red-400 text-xs font-bold leading-none">×</span>
                </div>
                <p className="text-xs text-foreground/50 leading-relaxed">{rule}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      <div className="mx-6 md:mx-16 lg:mx-24 h-px bg-border" />

      {/* ── Color Palette ──────────────────────────────────────────────── */}
      <Section id="colors">
        <SectionLabel num="03" label="Color Palette" />

        <div className="mb-16">
          <h2 className="text-foreground mb-4" style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 400 }}>
            A palette drawn from <em>skin, earth, and bloom.</em>
          </h2>
          <p className="text-sm text-foreground/50 leading-relaxed max-w-lg">
            The Muse color system is organized into two groups: Primary — expressive, signature colors that carry the brand's character — and Neutral, the warm foundational tones that let the primaries breathe.
          </p>
        </div>

        {/* Primary swatches */}
        <div className="mb-4">
          <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30 mb-8">Primary Palette</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            {primaryColors.map((c, i) => <ColorCard key={c.hex} color={c} index={i} />)}
          </div>
        </div>

        <div className="my-16 h-px bg-border" />

        {/* Neutral swatches */}
        <div>
          <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30 mb-8">Neutral Palette</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {neutralColors.map((c, i) => <ColorCard key={c.hex} color={c} index={i} />)}
          </div>
        </div>

        {/* Color pairings */}
        <div className="mt-20">
          <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30 mb-8">Approved Pairings</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { fg: "#810B38", bg: "#F6F3EB", label: "Crimson on Ivory" },
              { fg: "#F6F3EB", bg: "#541A1A", label: "Ivory on Burgundy" },
              { fg: "#2A1010", bg: "#F1E2D1", label: "Espresso on Parchment" },
              { fg: "#F6F3EB", bg: "#869B7E", label: "Ivory on Sage" },
            ].map((pair) => (
              <div key={pair.label}>
                <div
                  className="h-24 flex items-center justify-center text-xs font-medium tracking-widest uppercase"
                  style={{ backgroundColor: pair.bg, color: pair.fg, letterSpacing: "0.1em" }}
                >
                  Aa
                </div>
                <p className="text-xs text-foreground/40 mt-3 leading-tight">{pair.label}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      <div className="mx-6 md:mx-16 lg:mx-24 h-px bg-border" />

      {/* ── Typography ─────────────────────────────────────────────────── */}
      <Section id="typography">
        <SectionLabel num="04" label="Typography" />

        <div className="grid md:grid-cols-2 gap-16 mb-20 items-start">
          <div>
            <h2 className="text-foreground mb-4" style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 400 }}>
              Two voices, one conversation.
            </h2>
            <p className="text-sm text-foreground/50 leading-relaxed">
              Bodoni Moda carries the brand's editorial authority — high-contrast, fashion-forward, and unmistakably intentional. DM Sans provides the clean geometric warmth that makes the brand approachable in body copy and functional elements.
            </p>
          </div>

          {/* Font specimens side by side */}
          <div className="flex flex-col gap-8">
            <div className="border-l-2 pl-6" style={{ borderColor: "#810B38" }}>
              <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30 mb-2">Display / Headlines</p>
              <p style={{ fontFamily: "var(--font-display)", fontSize: "2.5rem", fontWeight: 500, lineHeight: 1 }} className="text-foreground">
                Bodoni Moda
              </p>
              <p style={{ fontFamily: "var(--font-display)", fontSize: "1rem", fontStyle: "italic", fontWeight: 400 }} className="text-foreground/50 mt-1">
                Regular · Medium · Italic
              </p>
            </div>
            <div className="border-l-2 pl-6" style={{ borderColor: "#869B7E" }}>
              <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30 mb-2">Body / UI</p>
              <p style={{ fontSize: "2.5rem", fontWeight: 400, lineHeight: 1 }} className="text-foreground font-sans">
                DM Sans
              </p>
              <p style={{ fontSize: "1rem", fontWeight: 300 }} className="text-foreground/50 mt-1 font-sans">
                Light · Regular · Medium
              </p>
            </div>
          </div>
        </div>

        {/* Type scale */}
        <div className="space-y-0">
          <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-foreground/30 mb-8">Type Scale</p>
          {typeScale.map((item, i) => (
            <div
              key={item.label}
              className="flex items-baseline gap-6 py-6 border-t border-border first:border-t-0"
            >
              <div className="w-20 shrink-0">
                <p className="text-[10px] tracking-[0.15em] uppercase text-foreground/30 font-medium">{item.label}</p>
              </div>
              <div className="flex-1 min-w-0">
                <p
                  className="text-foreground leading-tight truncate"
                  style={{
                    fontFamily: item.font === "display" ? "var(--font-display)" : "var(--font-body)",
                    fontSize: item.size,
                    fontWeight: item.weight,
                    letterSpacing: item.letterSpacing,
                    textTransform: item.uppercase ? "uppercase" : undefined,
                  }}
                >
                  {item.sample}
                </p>
              </div>
              <div className="shrink-0 text-right hidden md:block">
                <p className="text-[10px] text-foreground/25 font-mono">{item.size}</p>
                <p className="text-[10px] text-foreground/25 font-mono">{item.weight}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <div className="mx-6 md:mx-16 lg:mx-24 h-px bg-border" />

      {/* ── Brand Voice ────────────────────────────────────────────────── */}
      <Section id="voice">
        <SectionLabel num="05" label="Brand Voice" />

        <div className="mb-16">
          <h2 className="text-foreground mb-4" style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 400 }}>
            How Muse speaks.
          </h2>
          <p className="text-sm text-foreground/50 leading-relaxed max-w-lg">
            Every word written under the Muse name is an extension of the brand's identity. Copy should feel like a whispered recommendation from a trusted friend who also happens to be one of the best in the industry.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {voiceWords.map((v, i) => (
            <div key={v.word} className="p-8 bg-card border border-border">
              <p
                className="text-foreground mb-4"
                style={{ fontFamily: "var(--font-display)", fontSize: "2rem", fontWeight: 500 }}
              >
                {v.word}
              </p>
              <p className="text-sm text-foreground/55 leading-relaxed mb-8">{v.description}</p>

              <div className="space-y-3">
                <div className="flex gap-3">
                  <span className="text-[10px] tracking-wider uppercase font-medium text-secondary mt-0.5 shrink-0">Do</span>
                  <p className="text-xs text-foreground/60 italic leading-relaxed">{v.do}</p>
                </div>
                <div className="flex gap-3">
                  <span className="text-[10px] tracking-wider uppercase font-medium text-primary mt-0.5 shrink-0">Don't</span>
                  <p className="text-xs text-foreground/40 italic leading-relaxed line-through">{v.dont}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <div className="mx-6 md:mx-16 lg:mx-24 h-px bg-border" />

      {/* ── Photography Style ──────────────────────────────────────────── */}
      <Section id="photography">
        <SectionLabel num="06" label="Photography Style" />

        <div className="grid md:grid-cols-2 gap-16 mb-16 items-start">
          <div>
            <h2 className="text-foreground mb-4" style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 400 }}>
              Images that feel <em>lived in.</em>
            </h2>
            <p className="text-sm text-foreground/50 leading-relaxed mb-6">
              Muse photography is warm, intimate, and editorial. Natural window light is preferred. Skin tones are honored without over-retouching. Every frame should feel like a stolen moment — never staged, always real.
            </p>
            <div className="space-y-4">
              {[
                { label: "Lighting", value: "Natural, soft. Window light. Avoid harsh flash or over-lit studio setups." },
                { label: "Color Grade", value: "Warm-neutral. Slightly raised blacks, gentle highlights. Never cool or desaturated." },
                { label: "Subjects", value: "Close crops, hands, texture, detail. Full-figure portraits are secondary to intimate detail shots." },
                { label: "Backgrounds", value: "Clean, textural — cream plaster, warm linen, stone. No busy patterns." },
              ].map((item) => (
                <div key={item.label} className="flex gap-4">
                  <p className="text-[10px] tracking-[0.15em] uppercase font-medium text-foreground/30 w-20 shrink-0 pt-0.5">{item.label}</p>
                  <p className="text-xs text-foreground/55 leading-relaxed">{item.value}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Mood board grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 aspect-[16/9] overflow-hidden bg-muted">
              <img
                src="https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&h=450&fit=crop&auto=format"
                alt="Hair styling close-up"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-square overflow-hidden bg-muted">
              <img
                src="https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=400&h=400&fit=crop&auto=format"
                alt="Makeup brushes and tools"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-square overflow-hidden bg-muted">
              <img
                src="https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400&h=400&fit=crop&auto=format"
                alt="Salon atmosphere"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Photography dos/don'ts */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-8 border border-border">
            <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-secondary mb-5">Preferred Subjects</p>
            <ul className="space-y-2">
              {[
                "Hands at work — brushes, hair pins, tools of craft",
                "Texture close-ups — fabric, skin, product swatches",
                "Natural light portraits, slightly underexposed",
                "The studio environment — calm, curated, clean",
                "Candid moments between artist and client",
              ].map((item) => (
                <li key={item} className="flex gap-3 text-xs text-foreground/55 leading-relaxed">
                  <span className="text-secondary mt-0.5 shrink-0">—</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div className="p-8 border border-border">
            <p className="text-[10px] tracking-[0.2em] uppercase font-medium text-primary mb-5">Avoid</p>
            <ul className="space-y-2">
              {[
                "Stock photography with generic beauty clichés",
                "Heavy filter effects or artificial color grading",
                "Before/after compositions that feel clinical",
                "Overly bright, washed-out, or cool-toned images",
                "Posed smiles or performative expressions",
              ].map((item) => (
                <li key={item} className="flex gap-3 text-xs text-foreground/40 leading-relaxed">
                  <span className="text-primary mt-0.5 shrink-0">×</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      {/* ── Footer ─────────────────────────────────────────────────────── */}
      <footer style={{ backgroundColor: "#541A1A" }} className="px-6 md:px-16 lg:px-24 py-20">
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-10">
          <div>
            <div className="w-28 mb-8 opacity-80">
              <ImageWithFallback
                src={logoImg}
                alt="Muse by Anahita"
                className="w-full object-contain"
                style={{ filter: "invert(1) brightness(1.05)", mixBlendMode: "screen" }}
              />
            </div>
            <p className="text-[11px] tracking-[0.15em] uppercase" style={{ color: "rgba(246,243,235,0.35)" }}>
              Brand Guidelines · Version 1.0
            </p>
            <p className="text-[11px] mt-1" style={{ color: "rgba(246,243,235,0.2)" }}>
              © 2025 Muse by Anahita. All rights reserved.
            </p>
          </div>

          <div className="text-right">
            <p className="text-[10px] tracking-[0.2em] uppercase font-medium mb-3" style={{ color: "rgba(246,243,235,0.3)" }}>
              For brand inquiries
            </p>
            <p className="text-sm" style={{ color: "rgba(246,243,235,0.55)", fontFamily: "var(--font-display)", fontStyle: "italic" }}>
              hello@musebyanahita.com
            </p>
          </div>
        </div>
      </footer>

    </div>
  );
}
