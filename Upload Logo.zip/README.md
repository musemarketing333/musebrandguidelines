
  # Upload Logo

  This is a code bundle for Upload Logo. The original project is available at https://www.figma.com/design/xDF2CC2nUzIlUNbuyVC7NR/Upload-Logo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  